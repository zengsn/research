run the code as follows:
1.open m-file "distinctive_sparse_representation_via_L2_regularization.m";
2.run this file.